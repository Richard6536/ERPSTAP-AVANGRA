package com.example.erpstap.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.erpstap.R;

public class IniciarSesionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_sesion);
    }
}
